﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MTN.Controllers
{
    public class TayNgheController : Controller
    {
        // GET: TayNghe
        public ActionResult Headphones()
        {
            return View();
        }
    }
}