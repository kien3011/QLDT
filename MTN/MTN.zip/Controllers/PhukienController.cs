﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MTN.Controllers
{
    public class PhukienController : Controller
    {
        // GET: Phukien
        public ActionResult PhuKienpartial()
        {
            return View();
        }
    }
}